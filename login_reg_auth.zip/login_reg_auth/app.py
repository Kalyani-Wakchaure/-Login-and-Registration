from flask import Flask, render_template, request, redirect, url_for, flash
import mysql.connector

app = Flask(__name__)
app.secret_key = "49494asdklfjasdklflaksdf" 

# MySQL configurations
db_connection = mysql.connector.connect(
    host='localhost',
    user='root',
    password='Cdac@2022',
    database='flask_auth'
)
cursor = db_connection.cursor()

# Registration route
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        contact = request.form['contact']
        password = request.form['password']
        confirm_password = request.form['confirm_password']

        if password != confirm_password:
            flash('Passwords do not match!', 'error')
        else:
            try:
                cursor.execute("INSERT INTO users (name, email, contact, password) VALUES (%s, %s, %s, %s)",
                               (name, email, contact, password))
                db_connection.commit()
                flash('Registration successful!', 'success')
                return redirect(url_for('login'))
            except mysql.connector.Error as error:
                flash(f'Error: {error}', 'error')

    return render_template('register.html')

# Login route
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        cursor.execute("SELECT * FROM users WHERE email = %s AND password = %s", (email, password))
        user = cursor.fetchone()

        if user:
            flash('Login successful!', 'success')
            # Redirect to the 'index' page after successful login
            return redirect(url_for('index'))
        else:
            flash('Login failed. Please check your email and password.', 'error')

    return render_template('login.html')



@app.route('/index')
def index():
    # Placeholder for index page logic
    return render_template('index.html')


if __name__ == '__main__':
    app.run(debug=True)
